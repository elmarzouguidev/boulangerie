                    <!--section  -->
                    <section class="parallax-section" data-scrollax-parent="true" style="background-color:#47a1a2 " >
                        <div class="overlay op7" ></div>
                        <!--container-->
                        <div class="container">
                            <div class="video_section-title fl-wrap">
                                {{-- <h4>Aliquam erat volutpat interdum</h4> --}}
                                <h2>
                                    créer votre patisserie Digital
                                </h2>
                            </div>
                            <a href="" class="promo-link big_prom">
                                <i class="fal fa-link">
                                </i>
                                <span>Cliquez ici !</span>
                            </a>
                        </div>
                    </section>
                    <!--section end-->