<section id="sec3">
    <div class="container">
        <div class="section-title">
            <h2> Actualités</h2>
            {{-- <div class="section-subtitle">the crew</div> --}}
            <span class="section-separator"></span>
            {{-- <p>
                Explore some of the best tips fro
                m around the city from our partners and friends.
            </p> --}}
        </div>
        <div class="about-wrap team-box2 fl-wrap">
           <!----Haymacproduction-- blog -->
                <div class="team-box">
                    <div class="team-photo">
                        <img src="frontEnd/images/all/bakery2.jpg" alt="" class="respimg">
                    </div>
                    <div class="team-info fl-wrap">
                        <h3>
                            <a href="{{route('blog.single','la-patisserie-du-monde')}}">
                                Un comptoir de pâtisseries à emporter au Ritz
                            </a>
                        </h3>
                        <h4>author</h4>
                        <p>
                            Le pâtissier star rouvre
                            les portes de sa boutique 
                            parisienne et propose désormais
                            de réserver ses douceurs sur son
                            site Internet. À récupérer sur place.
                         </p>
                        {{-- <div class="team-social">
                            <ul class="no-list-style">
                                <li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fab fa-vk"></i></a></li>
                            </ul>
                        </div> --}}
                    </div>
                </div>

                <div class="team-box">
                    <div class="team-photo">
                        <img src="frontEnd/images/all/bakery3.jpg" alt="" class="respimg">
                    </div>
                    <div class="team-info fl-wrap">
                        <h3>
                            <a href="{{route('blog.single','la-patisserie-du-monde')}}">
                                Un comptoir de pâtisseries à emporter au Ritz
                            </a>
                        </h3>
                        <h4>author</h4>
                        <p>
                            Le pâtissier star rouvre
                            les portes de sa boutique 
                            parisienne et propose désormais
                            de réserver ses douceurs sur son
                            site Internet. À récupérer sur place.
                         </p>
                        {{-- <div class="team-social">
                            <ul class="no-list-style">
                                <li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fab fa-vk"></i></a></li>
                            </ul>
                        </div> --}}
                    </div>
                </div>

                <div class="team-box">
                    <div class="team-photo">
                        <img src="frontEnd/images/all/bakery1.jpg" alt="" class="respimg">
                    </div>
                    <div class="team-info fl-wrap">
                        <h3>
                            <a href="{{route('blog.single','la-patisserie-du-monde')}}">
                                Un comptoir de pâtisseries à emporter au Ritz
                            </a>
                        </h3>
                        <h4>author</h4>
                        <p>
                            Le pâtissier star rouvre
                            les portes de sa boutique 
                            parisienne et propose désormais
                            de réserver ses douceurs sur son
                            site Internet. À récupérer sur place.
                         </p>
                        {{-- <div class="team-social">
                            <ul class="no-list-style">
                                <li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fab fa-vk"></i></a></li>
                            </ul>
                        </div> --}}
                    </div>
                </div>
            <!----Haymacproduction-- blog -->
        </div>
    </div>
    <div class="waveWrapper waveAnimation">
      <div class="waveWrapperInner bgMiddle">
        <div class="wave-bg-anim waveMiddle" style="background-image: url('frontEnd/images/wave-top.png')"></div>
      </div>
      <div class="waveWrapperInner bgBottom">
        <div class="wave-bg-anim waveBottom" style="background-image: url('frontEnd/images/wave-top.png')"></div>
      </div>
    </div> 						
</section>