<section class="gray-bg">
                        <div class="container">
                            <div class="clients-carousel-wrap fl-wrap">
                                <div class="cc-btn   cc-prev"><i class="fal fa-angle-left"></i></div>
                                <div class="cc-btn cc-next"><i class="fal fa-angle-right"></i></div>
                                <div class="clients-carousel">
                                    <div class="swiper-container">
                                        <div class="swiper-wrapper">
                                            <!--client-item-->
                                            <div class="swiper-slide">
                                                <a href="#" class="client-item"><img src="{{asset('frontEnd/images/logoo.png')}}" alt=""></a>
                                            </div>
                                            <!--client-item end-->
                                            <!--client-item-->
                                            <div class="swiper-slide">
                                                <a href="#" class="client-item"><img src="{{asset('frontEnd/images/logoo.png')}}" alt=""></a>
                                            </div>
                                            <!--client-item end-->
                                            <!--client-item-->
                                            <div class="swiper-slide">
                                                <a href="#" class="client-item"><img src="{{asset('frontEnd/images/logoo.png')}}" alt=""></a>
                                            </div>
                                            <!--client-item end-->
                                            <!--client-item-->
                                                                                        <!--client-item-->
                                                                                        <div class="swiper-slide">
                                                                                            <a href="#" class="client-item"><img src="{{asset('frontEnd/images/logoo.png')}}" alt=""></a>
                                                                                        </div>
                                                                                        <!--client-item end-->
                                                                                        <!--client-item-->
                                                                                        <div class="swiper-slide">
                                                                                            <a href="#" class="client-item"><img src="{{asset('frontEnd/images/logoo.png')}}" alt=""></a>
                                                                                        </div>
                                                                                        <!--client-item end-->
                                                                                        <!--client-item-->
                                                                                        <div class="swiper-slide">
                                                                                            <a href="#" class="client-item"><img src="{{asset('frontEnd/images/logoo.png')}}" alt=""></a>
                                                                                        </div>
                                                                                        <!--client-item end-->
                                                                                        <!--client-item-->
                                                                                                                                                                                                                                                    
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>