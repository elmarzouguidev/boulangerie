<section class="parallax-section single-par" data-scrollax-parent="true">
    <div class="bg par-elem "  data-bg="frontEnd/images/bg/1.jpg" data-scrollax="properties: { translateY: '30%' }"></div>
    <div class="overlay op7"></div>
    <div class="container">
        <div class="section-title center-align big-title">
            <h2><span>Ecole de patisserie</span></h2>
            <span class="section-separator"></span>
            <div class="breadcrumbs fl-wrap">
                <a href="{{route('home')}}">Accueil</a>
              
            </div>
        </div>
    </div>
    <div class="header-sec-link">
        <a href="#sec1" class="custom-scroll-link"><i class="fal fa-angle-double-down"></i></a> 
    </div>
</section>