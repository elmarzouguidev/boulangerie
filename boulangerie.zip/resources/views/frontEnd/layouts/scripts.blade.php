
<script src="{{asset('frontEnd/js/jquery.min.js')}}"></script>
<script src="{{asset('frontEnd/js/plugins.js')}}"></script>
<script src="{{asset('frontEnd/js/scripts.js')}}"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhP2hthe-1Te1XwbYEmgh6GL75g-9zQjQ&libraries=places&callback=initAutocomplete"></script>        
<script src="{{asset('frontEnd/js/map-plugins.js')}}"></script>
<script src="{{asset('frontEnd/js/map-listing.js')}}"></script>   

@yield('MuScript')
