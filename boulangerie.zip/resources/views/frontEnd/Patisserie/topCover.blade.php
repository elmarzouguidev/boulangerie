            {{-- Powred by Elmarzougui Abdelghafour at HayMacProduction--}}
            <!--  section  -->
                  <section class="parallax-section single-par" data-scrollax-parent="true">
                    <div class="bg par-elem "  data-bg="frontEnd/images/bg/1.jpg" data-scrollax="properties: { translateY: '30%' }"></div>
                    <div class="overlay op7"></div>
                    <div class="container">
                        <div class="section-title center-align big-title">
                            <h2><span>les Boulangerie</span></h2>
                            <span class="section-separator"></span>
                            <h4>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut nec tincidunt arcu, sit amet fermentum sem.</h4>
                        </div>
                    </div>
                    <div class="header-sec-link">
                        <a href="#sec1" class="custom-scroll-link"><i class="fal fa-angle-double-down"></i></a> 
                    </div>
                </section>
                <!--  section  end-->