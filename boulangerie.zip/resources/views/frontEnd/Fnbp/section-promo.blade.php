<section class="parallax-section video-section" data-scrollax-parent="true" id="sec2">
    <div class="bg par-elem "  data-bg="frontEnd/images/bg/1.jpg" data-scrollax="properties: { translateY: '30%' }"></div>
    <div class="overlay op7"></div>
    <!--container-->
    <div class="container">
        <div class="video_section-title fl-wrap">
            <h4>Aliquam erat volutpat interdum</h4>
            <h2>Get ready to start your exciting journey. <br> Our agency will lead you through the amazing digital world</h2>
        </div>
        <a href="https://vimeo.com/70851162" class="promo-link big_prom   image-popup"><i class="fal fa-play"></i><span>Promo Video</span></a>
    </div>
</section>