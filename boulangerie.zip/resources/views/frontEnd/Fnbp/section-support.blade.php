<section class="gray-bg absolute-wrap_section">
    <div class="container">
        <div class="absolute-wrap fl-wrap">
            <!-- features-box-container --> 
            <div class="features-box-container fl-wrap">
                <div class="row">
                    <!--features-box --> 
                    <div class="col-md-4">
                        <div class="features-box">
                            <div class="time-line-icon">
                                <i class="fal fa-headset"></i>
                            </div>
                            <h3>24 Hours Support</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in pulvinar neque. Nulla finibus lobortis pulvinar.    </p>
                        </div>
                    </div>
                    <!-- features-box end  --> 
                    <!--features-box --> 
                    <div class="col-md-4">
                        <div class="features-box gray-bg">
                            <div class="time-line-icon">
                                <i class="fal fa-users-cog"></i>
                            </div>
                            <h3>Admin Panel</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in pulvinar neque. Nulla finibus lobortis pulvinar.   </p>
                        </div>
                    </div>
                    <!-- features-box end  --> 
                    <!--features-box --> 
                    <div class="col-md-4">
                        <div class="features-box ">
                            <div class="time-line-icon">
                                <i class="fal fa-mobile"></i>
                            </div>
                            <h3>Mobile Friendly</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in pulvinar neque. Nulla finibus lobortis pulvinar.  </p>
                        </div>
                    </div>
                    <!-- features-box end  -->  
                </div>
            </div>
            <!-- features-box-container end  -->                             
        </div>
        <div class="section-separator"></div>
    </div>
</section>