<section   id="sec1" data-scrollax-parent="true">
    <div class="container">
        <div class="section-title">
            <h2> FNBP</h2>
            <div class="section-subtitle">FNBP</div>
            <span class="section-separator"></span>
            <p>Explore some of the best tips from around the city from our partners and friends.</p>
        </div>
        <!--about-wrap -->
        <div class="about-wrap">
            <div class="row">
                <div class="col-md-6">
                    <div class="list-single-main-media fl-wrap" style="box-shadow: 0 9px 26px rgba(58, 87, 135, 0.2);">
                        <img src="frontEnd/images/all/1.jpg" class="respimg" alt="">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="ab_text">
                        <div class="ab_text-title fl-wrap">
                            <h3>Our Awesome  Team <span>Story</span></h3>
                            <h4>Check video presentation to find   out more about us .</h4>
                            <span class="section-separator fl-sec-sep"></span>
                        </div>
                        <p>Ut euismod ultricies sollicitudin. Curabitur sed dapibus nulla. Nulla eget iaculis lectus. Mauris ac maximus neque. Nam in mauris quis libero sodales eleifend. Morbi varius, nulla sit amet rutrum elementum, est elit finibus tellus, ut tristique elit risus at metus. Sed tempor iaculis massa faucibus feugiat. </p>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in pulvinar neque. Nulla finibus lobortis pulvinar. Donec a consectetur nulla. Nulla posuere sapien vitae lectus suscipit, et pulvinar nisi tincidunt. Curabitur convallis fringilla diam sed aliquam. Sed tempor iaculis massa faucibus feugiat. In fermentum facilisis massa, a consequat purus viverra. Aliquam erat volutpat. Curabitur convallis fringilla diam sed aliquam. Sed tempor iaculis massa faucibus feugiat. In fermentum facilisis massa, a consequat purus viverra.
                        </p>
                        <a href="http://fnbp.ma/" class="btn color2-bg float-btn custom-scroll-link">Consulter notre site web <i class="fal fa-users"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- about-wrap end  --> 
        <span class="fw-separator"></span>
        {{-- <div class=" single-facts bold-facts fl-wrap">
            <!-- inline-facts -->
            <div class="inline-facts-wrap">
                <div class="inline-facts">
                    <div class="milestone-counter">
                        <div class="stats animaper">
                            <div class="num" data-content="0" data-num="1254">1254</div>
                        </div>
                    </div>
                    <h6>New Visiters Every Week</h6>
                </div>
            </div>
            <!-- inline-facts end -->
            <!-- inline-facts  -->
            <div class="inline-facts-wrap">
                <div class="inline-facts">
                    <div class="milestone-counter">
                        <div class="stats animaper">
                            <div class="num" data-content="0" data-num="12168">12168</div>
                        </div>
                    </div>
                    <h6>Happy customers every year</h6>
                </div>
            </div>
            <!-- inline-facts end -->
            <!-- inline-facts  -->
            <div class="inline-facts-wrap">
                <div class="inline-facts">
                    <div class="milestone-counter">
                        <div class="stats animaper">
                            <div class="num" data-content="0" data-num="2172">2172</div>
                        </div>
                    </div>
                    <h6>Won Awards</h6>
                </div>
            </div>
            <!-- inline-facts end -->
            <!-- inline-facts  -->
            <div class="inline-facts-wrap">
                <div class="inline-facts">
                    <div class="milestone-counter">
                        <div class="stats animaper">
                            <div class="num" data-content="0" data-num="732">732</div>
                        </div>
                    </div>
                    <h6>New Listing Every Week</h6>
                </div>
            </div>
            <!-- inline-facts end -->
        </div> --}}
    </div>
</section>