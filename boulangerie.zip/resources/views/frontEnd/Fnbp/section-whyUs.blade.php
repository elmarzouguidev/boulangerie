<section class="parallax-section" data-scrollax-parent="true" id="sec4">
    <div class="bg par-elem "  data-bg="frontEnd/images/bg/1.jpg" data-scrollax="properties: { translateY: '30%' }"></div>
    <div class="overlay op7"></div>
    <!--container-->
    <div class="container">
        <div class="section-title center-align big-title">
            <h2><span>Why Choose Us</span></h2>
            <span class="section-separator"></span>
            <h4>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut nec tincidunt arcu, sit amet fermentum sem.</h4>
        </div>
    </div>
</section>