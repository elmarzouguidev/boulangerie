<div class="listsearch-input-wrap_contrl fl-wrap">
    <div class="container">
        <ul class="tabs-menu fl-wrap no-list-style">
            <li class="current"><a href="#filters-search"> <i class="fal fa-sliders-h"></i> Filters </a></li>
            <li><a href="#category-search"> <i class="fal fa-image"></i>Categories </a></li>
        </ul>
    </div>
</div>