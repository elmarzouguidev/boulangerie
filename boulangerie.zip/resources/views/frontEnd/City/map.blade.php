       <!-- Map -->
       <div class="map-container column-map right-pos-map fix-map hid-mob-map">
        <div id="map-main"></div>
        <ul class="mapnavigation no-list-style">
            <li><a href="#" class="prevmap-nav mapnavbtn"><span><i class="fas fa-caret-left"></i></span></a></li>
            <li><a href="#" class="nextmap-nav mapnavbtn"><span><i class="fas fa-caret-right"></i></span></a></li>
        </ul>
        <div class="scrollContorl mapnavbtn tolt"   data-microtip-position="top-left" data-tooltip="Enable Scrolling"><span><i class="fal fa-unlock"></i></span></div>
        <div class="location-btn geoLocation tolt" data-microtip-position="top-left" data-tooltip="Your location"><span><i class="fal fa-location"></i></span></div>
        <div class="map-close"><i class="fas fa-times"></i></div>
    </div>
    <!-- Map end -->