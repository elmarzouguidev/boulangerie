@extends('frontEnd.layouts.app')

{{-- Powred by Elmarzougui Abdelghafour at HayMacProduction--}}

@section('content')

   @include('frontEnd.Blog.topCover')
   
   @include('frontEnd.Blog.main')

@endsection